import java.awt.*;
import javax.swing.*;
import java.awt.event.*;

public class LabelMessages
        extends JFrame implements ActionListener {
        
        private String id;
        private JTextField messageId = new JTextField(2);
        private JTextField label = new JTextField(3);
        private JButton mark = new JButton("Add label");
        private JButton exit = new JButton("Exit");
        private JTextArea textArea = new JTextArea();
        private JScrollPane scrollPane = new JScrollPane(textArea);
        
        public LabelMessages(String id) {
            this.id = id;
            
            setLayout(new BorderLayout());
            setSize(500, 250);
            setResizable(false);
            setTitle("Message Lables");
            
            setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
            JPanel top = new JPanel();
            top.add(new JLabel("Message ID: "));
            top.add(messageId);
            top.add(new JLabel("Label: "));
            top.add(label);
            top.add(mark);
            mark.addActionListener(this);
            top.add(exit);
            
            exit.addActionListener(this);
            add("North", top);
            
            textArea.setFont(new Font(Font.MONOSPACED, Font.PLAIN, 12)); 
            textArea.setLineWrap(true);
            textArea.setWrapStyleWord(true);
            textArea.setPreferredSize(new Dimension(450, 150));
            textArea.setText("Id Priority From                           Label  Subject\n" + "== ======== ====                           =====  =======\n");
            scrollPane.setVerticalScrollBarPolicy(JScrollPane.VERTICAL_SCROLLBAR_ALWAYS);
            scrollPane.setPreferredSize(new Dimension(450, 150));
            textArea.setEditable(false);

            JPanel middle = new JPanel();
            middle.add(scrollPane); 
            add("Center", middle);
            
            setVisible(true);
        }
        
        public void actionPerformed(ActionEvent e) {
        try {
       
            if (e.getSource() == exit) {
               dispose();
            } else if (e.getSource() == mark) {
                
              String readLabel = label.getText();
              String readID = messageId.getText();
              
              textArea.append(MessageData.setLabel(readID, readLabel));
            }
        } catch (Exception ex) {
                      textArea.append("Please put in a label between 01-09");   
                   
                      }
            }   
             
            }
                 
                   
           
        




  
