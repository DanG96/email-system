
import java.awt.*;
import java.awt.event.*;
import javax.swing.*;

public class EmailManager extends JFrame
        implements ActionListener {
    {
       try {
            for (UIManager.LookAndFeelInfo info : UIManager.getInstalledLookAndFeels()) {
        if ("Nimbus".equals(info.getName())) {
            UIManager.setLookAndFeel(info.getClassName());
            break;
            }
            }
        } catch (Exception e) {
         //If Nimbus is not available, you can set the GUI to another look and feel.
        }
    }
   
    private JButton list = new JButton("List Messages");
    private JButton read = new JButton("Read Message");
    private JTextField idTextField = new JTextField(2);
    private JButton label = new JButton("Label Messages");
    private JButton newMessage = new JButton("New Message");
    private JButton deleteMes = new JButton("Delete Message");
    private JButton quit = new JButton("Exit");
    private JTextArea textArea = new JTextArea();
    private JScrollPane scrollPane = new JScrollPane(textArea);

    public static void main(String[] args) {
        new EmailManager();
    }

    public EmailManager() {
        
        JPanel p1 = new JPanel(new FlowLayout(FlowLayout.LEFT, 2, 2));
        JPanel p2 = new JPanel(new FlowLayout(FlowLayout.LEFT, 2, 2));
        setLayout(new BorderLayout());
        setSize(700, 300);
        setResizable(false);
        setTitle("Email Manager");
        // close application only by clicking the quit button
        setDefaultCloseOperation(WindowConstants.DO_NOTHING_ON_CLOSE);

        
        p1.add(list);
        list.addActionListener(this);
        p1.add(deleteMes);
        deleteMes.addActionListener(this);
        p1.add(read);
        read.addActionListener(this);
        p1.add(idTextField);
        p1.add(label);
        label.addActionListener(this);
        p1.add(newMessage);
        newMessage.addActionListener(this);
        p1.add(quit);
        quit.addActionListener(this);
        add("North", p1);
        
        p1.setBackground(Color.cyan);
        
        
        textArea.setFont(new Font(Font.MONOSPACED, Font.PLAIN, 12));
        textArea.setLineWrap(true);
        textArea.setWrapStyleWord(true);
        textArea.setPreferredSize(new Dimension(650, 200));
        scrollPane.setVerticalScrollBarPolicy(JScrollPane.VERTICAL_SCROLLBAR_ALWAYS);
        scrollPane.setPreferredSize(new Dimension(650, 200));
        textArea.setBackground(Color.CYAN);
        textArea.setEditable(false);
        
        JPanel middle = new JPanel();
        middle.add(scrollPane);
        add("Center", middle);

        textArea.setText(MessageData.listAll());
        
        setVisible(true);
        
     
        }

    public void actionPerformed(ActionEvent e) {
        if (e.getSource() == list) {
            textArea.setText(MessageData.listAll());
        } else if (e.getSource() == read) {
            new ReadMessage(idTextField.getText());
            
        } else if (e.getSource() == quit) {
            MessageData.close();
            System.exit(0);
        } else if (e.getSource() == label){
            new LabelMessages(idTextField.getText());
        } else if (e.getSource() == newMessage){
            new NewMesssage(idTextField.getText());
        } else if (e.getSource() == deleteMes) {
            new DeleteMessage(idTextField.getText());
        }
    }
}