import java.awt.*;
import javax.swing.*;
import java.awt.event.*;

public class DeleteMessage
        extends JFrame implements ActionListener {
        
        private String id;
        private JTextField messageId = new JTextField(2);
        
        private JButton del = new JButton("Delete message");
        private JButton exit = new JButton("Exit");
        private JTextArea textArea = new JTextArea();
        private JScrollPane scrollPane = new JScrollPane(textArea);
        
        public DeleteMessage(String id) {
            this.id = id;
            
            setLayout(new BorderLayout());
            setSize(500, 250);
            setResizable(false);
            setTitle("Delete messages");
            
            setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
            JPanel top = new JPanel();
            top.add(new JLabel("Message ID: "));
            top.add(messageId);
         
            top.add(del);
            del.addActionListener(this);
            top.add(exit);
            
            exit.addActionListener(this);
            add("North", top);
            
            textArea.setFont(new Font(Font.MONOSPACED, Font.PLAIN, 12)); 
            textArea.setLineWrap(true);
            textArea.setWrapStyleWord(true);
            textArea.setPreferredSize(new Dimension(450, 150));
            textArea.setText("Id Priority From                           Label  Subject\n" + "== ======== ====                           =====  =======\n");
            scrollPane.setVerticalScrollBarPolicy(JScrollPane.VERTICAL_SCROLLBAR_ALWAYS);
            scrollPane.setPreferredSize(new Dimension(450, 150));
            textArea.setEditable(false);

            JPanel middle = new JPanel();
            middle.add(scrollPane); 
            add("Center", middle);
            
            setVisible(true);
        }
        
        public void actionPerformed(ActionEvent e) {
        try {
       
            if (e.getSource() == exit) {
               dispose();
            } else if (e.getSource() == del) {
                 
            String readID = (messageId.getText());
           
           
            
            MessageData.deleteMesa(readID);
            
            }
        } catch (Exception ex) {
                      textArea.append("Please put in a label between 01-09");   
                   
                      }
            }   
             
            }
                 
                   