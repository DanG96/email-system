import java.awt.*;//this imports all the classes in the abstract windows toolkit as well as swing and even so that they can all be used in the program
import java.awt.event.*;
import java.io.IOException;
import javax.swing.*;

public class ReadMessage extends JFrame//this creates a class called ReadMessage that is public meaning that other classes can see it, 
//extends means that  all classes, whether they state so or not, will use JFrame
        implements ActionListener {//this is an event handler, it allows the user to user an action listener

   
    private String id;// this declares a new string that is private and is called id
    private JTextField priority = new JTextField(2);// declares a private textfield called priority, 2 represents the number of columns in the field  
    private JButton update = new JButton("Update");//declares a private button called "Update", creates a button
    private JButton close = new JButton("Exit");//declares a private button called "Close", creates a button
    private JTextArea textArea = new JTextArea();//declares a private test area, creates a text area where text can be displayed
    private JScrollPane scrollPane = new JScrollPane(textArea);//declares a scroll bar that will change the text area when used

    public ReadMessage(String id) {// this is a constructor as it uses the same name as the class,
       this.id = id;//this refers to the action listeners and in this case in linked to the string id

        setLayout(new BorderLayout());// this sets the layout type to BorderLayout meaning that you can set actions to north, south, east, west etc
        setSize(500, 250);//this sets the GUI to 500 pixels accrose and 250 pixels down
        setResizable(false);// this means that the user cannot resize the GUI 
        setTitle("Message Details");// this sets the title to "Message Details" at the top
 
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);//?? this means that when the GUI is closed it will delete it
        JPanel top = new JPanel();//?? this adds a panel so that buttons can be added this can act as layers in the JFrame
        top.add(new JLabel("Enter Priority (1-5):"));//this creates a lable to the frame so that the user can input the priorty or the message
        top.add(priority);// this adds the button "priority" to the frame, "top" refers to the location in the border layout
        top.add(update);// adds the button "update" to the frame to the top of it
        update.addActionListener(this);//this allows the button "update" to do something when the user interacts with it, in this case when the user clicks the button
        top.add(close);//adds the button "close" to the frame at the top
        close.addActionListener(this);//this allows the button "close" to do something when the user interacts with it, in this case when the user clicks the butto
        add("North", top);//this means whenever "top" is written in the code that will mean the code will be placed in the north section of the borderlayout
        
        textArea.setFont(new Font(Font.MONOSPACED, Font.PLAIN, 12));//this sets the font, the font size and the format of the text the user inputs into the read message text area
        textArea.setLineWrap(true);//this makes sure that when the user types and it reaches the end of the window it moves to the next line, when false it continues the window 
        textArea.setWrapStyleWord(true);// this means that the text area should wrap lines at the word rather than character
        textArea.setPreferredSize(new Dimension(450, 150));// this sets the intial text area to 450 pixels down and 150 across, the scroll bar will not scroll past 450 pixels
        scrollPane.setVerticalScrollBarPolicy(JScrollPane.VERTICAL_SCROLLBAR_ALWAYS);//this means that the scroll bar is set vertically all the time meaning when it is set to never th scroll bar will not appear
        scrollPane.setPreferredSize(new Dimension(450, 150));//this sets the size of the box of which the user can write in
        textArea.setEditable(false);
        
        JPanel middle = new JPanel();//this creates a new JPanel called "middle" 
        middle.add(scrollPane);//this adds the scrollPane JPanel, it also adds it the middle section to the borderlayout  
        add("Center", middle);//this adds the "middle" JPanel to the center of the panel

        displayMessage();//this displays the message to the user when it is written
        
        setVisible(true);//this makes the panel visible
    }

    public void actionPerformed(ActionEvent e) {
        try {
        
        if (e.getSource() == update) {//if the user presses the update button, or if the source is equal to the update button 
            int priorityValue = Integer.parseInt(priority.getText());//if the update button is pressed it will convert the text in priority into an integer
            MessageData.setPriority(id, priorityValue);//this will display in message date the converted priority value 
            displayMessage();//if the update button is pressed the message will diplay
        } else if (e.getSource() == close) {// if th sourse is not equal to the update it means that the user has closed it
            dispose();//if the user pressed the close button then the window will be closed 
           
        }  
        } catch (Exception ex) {
            textArea.setText("Please insert an integer to set priority");
        }
    }

    private void displayMessage() {
         
        String subject = MessageData.getSubject(id);// this creates a string called "subject" and assigns it to MessageData.getSubject(id)
        if (subject == null) {//this means that if the string "subject" has no value then it will print "no such message"
            textArea.setText("No such message");// this will print in the text area if the subjec has no value
        } else {//this event will occur if the subject is equal to anything other than null
            textArea.setText("Subject: " + subject);//this prints out the text that the user has written as well as "Subject :"
            textArea.setText("From: " + MessageData.getSender(id));//this would print and tell the user who sent the message using their id
            textArea.append("\nTo: " + MessageData.getRecipient(id));//this will print who they are sending a message to to
            textArea.append("\nPriority: " + MessageData.stars(MessageData.getPriority(id)));//this sets the priority of the message when selected by the user
            textArea.append("\n\n" + MessageData.getMessage(id));//prints the message that the user has written
            
        }
        }
    }
