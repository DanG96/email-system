    import java.awt.*;
    import javax.swing.*;
    import java.awt.event.*;
 
public class NewMesssage
        extends JFrame implements ActionListener {
        
      
        private String id;
        private JTextField recipient = new JTextField(6);
        private JTextField subject = new JTextField(6);
        private JTextField ID = new JTextField(6);
        private JButton send = new JButton("Send");
        private JButton exit = new JButton("Exit");
        private JTextArea textArea = new JTextArea();
        private JScrollPane scrollPane = new JScrollPane(textArea);
        
        public NewMesssage(String id) {
            this.id = id;           
            setLayout(new BorderLayout());
            setSize(650, 550);
            setResizable(false);
            setTitle("New Message");
            
            setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
            JPanel top = new JPanel();
       
            top.add(new JLabel("Subject: "));
            top.add(subject);
            top.add(new JLabel("Recipient"));
            top.add(recipient); 
            top.add(new JLabel("ID "));
            top.add(ID);
            top.add(send);
            
            send.addActionListener(this);
            top.add(exit);
                     
            exit.addActionListener(this);
            add("North", top);
           
            textArea.setFont(new Font(Font.MONOSPACED, Font.PLAIN, 12)); 
            textArea.setLineWrap(true);
            textArea.setWrapStyleWord(true);
            textArea.setPreferredSize(new Dimension(450, 150));
            scrollPane.setVerticalScrollBarPolicy(JScrollPane.VERTICAL_SCROLLBAR_ALWAYS);
            scrollPane.setPreferredSize(new Dimension(450, 150));

            JPanel middle = new JPanel();
            middle.add(scrollPane); 
            add("Center", middle);
        
            setVisible(true);
        }
        
    
                        
 public void actionPerformed(ActionEvent e)
     {
        
        if (e.getSource() == send) { 

            String subjectTxt = (subject.getText());
            String readID = (ID.getText()); 
            String recipientTxt = (recipient.getText());
            String messageTxt = (textArea.getText());
            int priority = 1;
            String sender = "gd410@gre.ac.uk";
            String label = "Todo";
           
            
            MessageData.setMessage2(readID, recipientTxt, subjectTxt , label, priority, sender, messageTxt);
           
        } else if (e.getSource() == exit) { 
            dispose();
        }
  
     }        
              
     }
 
    




